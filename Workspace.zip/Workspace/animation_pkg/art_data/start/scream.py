def exhale():
    return 'Inhale Exhale '*6

def scream():
    return 'Ahhhhhhhhhhhhhhhhhhhhhh!!!!!!!!!!!!!!!!!!'

def narrate_1():
    return "You wake up again from a nightmare.\n'It's just a dream.' you say."

def narrate_2():
    return "However,the burden on your shoulders in the dream hasn't lightened; you can feel some heavy backpack pulling you into a deeper abyss."

def narrate_3():
    return "You can't control it, aware that you are sinking into the bed..."


