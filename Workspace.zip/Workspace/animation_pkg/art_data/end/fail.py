def ghost():
    return r"""
               (                                (
                )           )        (                   )
              (                       )      )            .---.
          )              (     .-""-.       (        (   /     \
         ( .-""-.  (      )   / _  _ \        )       )  |() ()|
          / _  _ \   )        |(_\/_)|  .---.   (        (_ 0 _)
          |(_)(_)|  ( .---.   (_ /\ _) /     \    .-""-.  |xxx|
          (_ /\ _)   /     \   |v==v|  |<\ />|   / _  _ \ '---'
           |wwww|    |(\ /)|(  '-..-'  (_ A _)   |/_)(_\|
           '-..-'    (_ o _)  )  .---.  |===|    (_ /\ _)
                      |===|  (  /     \ '---'     |mmmm|
                      '---'     |{\ /}|           '-..-'
                                (_ V _)
                                 |mmm|
                                 '---'
    """

def naration():
    return """
Can't find your way out of the maze? Then you'll be trapped in your own mental labyrinth forever! You'll never escape Depressionland!
    """